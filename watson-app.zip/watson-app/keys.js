const watsonKeySpeechtoText = 'nNO_bdmfN9w0f7aD71k62YHCOTqirx_rJcBoD8wjn0a-';
//This is my Watson Key

exports.watsonKeySpeechtoText = watsonKeySpeechtoText;


